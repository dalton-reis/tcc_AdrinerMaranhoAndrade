[< Home](/smalg-platform)

# Integração com o Github

### Onde ficam meus problemas?

Quando você autentica com o Github, ao criar um problema criamos um repositório na sua conta chamado `_smalg-platform-problems`. Nele estará contido todos os seus problemas criados. Caso você queira compartilhar sem que seja necessário outros usuários autenticar no Github, você pode realizar o download da pasta `smalg-problems` e compartilhar. A execução de um problema pode ser feita também a partir de um arquivo.

### O que é feito na minha conta?

Apenas é realizado a consulta em suas informações de perfil e gerenciado o repositório `_smalg-platform-problems`.