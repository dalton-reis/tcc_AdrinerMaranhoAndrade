# Smalg Platform

Educational platform for learning programming with visualization.