export enum PerspectiveType {

  BOTH = 'BOTH',
  ONLY_CODE = 'ONLY_CODE',
  ONLY_VISUALIZATION = 'ONLY_VISUALIZATION',

}
