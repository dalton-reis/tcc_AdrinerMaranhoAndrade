export interface Action {

  type: string;
  params?: any;

}
