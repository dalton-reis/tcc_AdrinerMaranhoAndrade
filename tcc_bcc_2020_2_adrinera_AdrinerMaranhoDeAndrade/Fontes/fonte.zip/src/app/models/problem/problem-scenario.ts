interface ProblemScenario {

  id?: string;
  name: string;
  description: string;
  code: string;
  active?: boolean;

}
