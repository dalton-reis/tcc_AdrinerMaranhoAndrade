export interface ProblemInfo {

  name: string;
  downloadUrl: string;

}
