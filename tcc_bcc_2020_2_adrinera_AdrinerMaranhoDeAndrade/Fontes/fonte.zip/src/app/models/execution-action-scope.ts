export enum ExecutionActionScope {

  GRAPHIC = 'GRAPHIC',

}
