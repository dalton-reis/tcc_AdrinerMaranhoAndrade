import { ExecutionActionScope } from './execution-action-scope';

export interface ExecutionActionType {

  scope: ExecutionActionScope;
  name: string;

}
