import { ExecutionBarState } from './execution-bar-state';

export interface ExecutionBarEvent {

  state: ExecutionBarState;

}
