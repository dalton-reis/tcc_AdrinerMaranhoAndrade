export enum ExecutionBarState {

  STOP = 'STOP',
  STEP_BACWARD = 'STEP_BACWARD',
  PLAY = 'PLAY',
  PAUSE = 'PAUSE',
  STEP_FORWARD = 'STEP_FORWARD',

}
