export interface User {

  login: string;
  name: string;
  avatarUrl: string;

}
