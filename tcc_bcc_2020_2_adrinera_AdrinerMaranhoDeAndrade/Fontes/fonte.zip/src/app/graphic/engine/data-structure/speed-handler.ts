export class SpeedHandler {

  static speed = 1000;

  static defaultSpeed() {
    SpeedHandler.speed = 1000;
  }

}
