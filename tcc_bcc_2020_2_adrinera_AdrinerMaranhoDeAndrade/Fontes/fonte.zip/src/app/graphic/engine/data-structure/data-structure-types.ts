export enum ElementTypes {

  PRIMITIVE = 'PRIMITIVE',
  CONTAINER = 'CONTAINER',
  OBJECT = 'OBJECT',

}
