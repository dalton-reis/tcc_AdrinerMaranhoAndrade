export interface MonacoEditorContext {

  name: string;
  code: string;

}
